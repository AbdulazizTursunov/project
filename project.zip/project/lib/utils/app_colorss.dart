import 'package:flutter/animation.dart';

class AppColors {
  static Color c0xffd2af84 = const Color(0xffd2af84);
  static Color c0xffefe3c8 = const Color(0xffefe3c8);
  static Color black = const Color(0xff000000);
  static Color white = const Color(0xffffffff);
  static Color c0xff201520 = const Color(0xff201520);
}
