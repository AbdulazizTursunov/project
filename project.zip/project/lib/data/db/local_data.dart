import '../model/expo.dart';

List<ProductInfo> products = [
  //electronic category
  ProductInfo(
      id: 1,
      name: 'Canoon13',
      category: 'Texnika',
      price: 300,
      article: 'ANd9GcQq70AvDsba%5^5#',
      barcode: '123456789012',
      brend: 'canoon',
      department: 'Kamera',
      measure: '10',
      image:
          "https://cdn.fotosklad.ru/unsafe/9becf433b5c14dc381255db0571d8634/image.jpg"),
  ProductInfo(
      id: 2,
      name: 'IDEALSOFT',
      category: 'Texnika',
      price: 250,
      article: 'rlcU0kAqvO#85@',
      barcode: '1865498',
      brend: 'Ideal',
      department: 'Mikrovalnovaya pech',
      measure: '20',
      image: "https://uzeltech.uz/wp-content/uploads/2019/11/elektrolyuks.jpg"),
  ProductInfo(
      id: 3,
      name: 'NetumScan Barcode',
      category: 'Texnika',
      price: 100,
      article: '45Hhvjvjd^75gdge5',
      barcode: '125489762356',
      brend: 'NetumScan',
      department: 'Barcode scanner',
      measure: '5',
      image: "https://m.media-amazon.com/images/I/71uWJVoD0RS._AC_SX466_.jpg"),
  ProductInfo(
      id: 4,
      name: 'HP 247',
      category: 'Texnika',
      price: 350,
      article: '67&U77PA%',
      barcode: '56894231587',
      brend: 'HP',
      department: 'Notebook',
      measure: '13',
      image:
          "https://www.supremeindia.com/uploads/products/20232006168725588664917b4ea278d.png"),
  // Perfume category
  ProductInfo(
      id: 5,
      name: 'Jadore',
      category: 'Perfume',
      price: 50,
      article: 'kl%70kAqvO',
      barcode: '1236458976',
      brend: 'Dior',
      department: 'Jadore',
      measure: '10',
      image:
          "https://olcha.uz/image/400x400/products/2022-11-19/parfyumernaya-voda-dior-jadore-eau-de-parfum-5ml-170133-1.jpeg"),
  ProductInfo(
      id: 6,
      name: 'Midnight Love',
      category: 'Perfume',
      price: 30,
      article: '5&HyN@k',
      barcode: '12457892365',
      brend: 'Barihin',
      department: 'MIDNIGHT love',
      measure: '18',
      image: "https://barihin.com/image/category/322.jpg"),
  ProductInfo(
      id: 7,
      name: 'LUCIFER',
      category: 'Perfume',
      price: 60,
      article: 'DfrSjsHY#h@5',
      barcode: '2598641234',
      brend: 'Eau Of Parfums',
      department: 'Lucifer perfume',
      measure: '10',
      image:
          "https://static.wixstatic.com/media/1bc864_170ee86606dc4798ab098e28d578f781~mv2.jpg/v1/fill/w_380,h_506,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/1bc864_170ee86606dc4798ab098e28d578f781~mv2.jpg"),
  ProductInfo(
      id: 8,
      name: 'DREAM BRIGHT',
      category: 'Perfume',
      price: 40,
      article: 'juG%!m594fg',
      barcode: '568912345',
      brend: 'BATZ & BODY WORKS',
      department: 'Dream Bright perfume',
      measure: '5',
      image:
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTdSTKsS9sgEikFxqHcxzoxqvx4W3Kp4mradLVfDeX0CcFuGmjgzFjW2QgplhRR1CZ5wd0&usqp=CAU"),
];
